import {
  SCHOOL_NAME,
  SCHOOL_DISTRICT,
  SCHOOL_OFFICE,
  STAFF_LIST,
  toKhmer,
  KH_MONTHS_SOLAR,
  KH_WEEKDAYS_LONG,
  formatKhmerLunarDate,
} from '../data/staff';
import { getKhmerHoliday, getKhmerLunarInfo } from './khmerCalendar';
import { DayAttendanceMap } from '../types';

export interface ExportHtmlOptions {
  filename: string;
  title: string;
  contentHtml: string;
  landscape?: boolean;
  customStyles?: string;
}

/**
 * Wraps any HTML content into a standalone, beautiful HTML document
 * with Google Fonts for Khmer, A4 print sizing, and a convenient non-printable top bar.
 */
export function generateStandaloneHtml({
  title,
  contentHtml,
  landscape = true,
  customStyles = '',
}: Omit<ExportHtmlOptions, 'filename'>): string {
  const pageOrientation = landscape ? 'landscape' : 'portrait';

  return `<!DOCTYPE html>
<html lang="km">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Kantumruy+Pro:wght@400;500;600;700&family=Moul&family=Noto+Sans+Khmer:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    @page {
      size: A4 ${pageOrientation};
      margin: 4mm;
    }
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      margin: 0;
      padding: 0;
      background-color: #f1f5f9;
      color: #0f172a;
      font-family: 'Kantumruy Pro', 'Noto Sans Khmer', sans-serif;
      -webkit-font-smoothing: antialiased;
    }
    .no-print {
      display: flex;
    }
    @media print {
      body {
        background-color: #ffffff !important;
      }
      .no-print {
        display: none !important;
      }
      .page-break {
        page-break-after: always !important;
      }
      .print-container {
        padding: 0 !important;
        box-shadow: none !important;
        border: none !important;
        max-width: 100% !important;
        margin: 0 !important;
      }
    }
    .top-toolbar {
      position: sticky;
      top: 0;
      z-index: 9999;
      background: #0f172a;
      color: #f8fafc;
      padding: 10px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      border-bottom: 2px solid #3b82f6;
    }
    .top-toolbar .title {
      font-weight: 700;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .top-toolbar .actions {
      display: flex;
      gap: 10px;
    }
    .btn {
      padding: 6px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      border: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      text-decoration: none;
      transition: all 0.2s;
    }
    .btn-print {
      background: #10b981;
      color: #ffffff;
    }
    .btn-print:hover {
      background: #059669;
    }
    .btn-close {
      background: #334155;
      color: #e2e8f0;
    }
    .btn-close:hover {
      background: #475569;
    }
    .print-container {
      max-width: ${landscape ? '297mm' : '210mm'};
      margin: 15px auto;
      background: #ffffff;
      padding: 6mm 8mm;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      border-radius: 4px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border: 1pt solid #000;
    }
    ${customStyles}
  </style>
</head>
<body>
  <div class="no-print top-toolbar">
    <div class="title">
      <span>📄 ${title}</span>
      <span style="font-size: 11px; opacity: 0.8; font-weight: normal; margin-left: 10px;">
        (${SCHOOL_NAME} • ស្រុកភ្នំស្រុក)
      </span>
    </div>
    <div class="actions">
      <button class="btn btn-print" onclick="window.print()" title="ចុចដើម្បីបោះពុម្ព ឬរក្សាទុកជា PDF">
        🖨️ បោះពុម្ព / រក្សាទុកជា PDF (Save as PDF)
      </button>
      <button class="btn btn-close" onclick="window.close()" title="បិទផ្ទាំងនេះ">
        ✕ បិទ
      </button>
    </div>
  </div>

  <div class="print-container">
    ${contentHtml}
  </div>
</body>
</html>`;
}

/**
 * Downloads a complete standalone .html file
 */
export function exportToHtmlFile(options: ExportHtmlOptions): void {
  const fullHtml = generateStandaloneHtml(options);
  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = options.filename.endsWith('.html') ? options.filename : `${options.filename}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Opens a dedicated printable window optimized for "Save as PDF" (រក្សាទុកជា PDF)
 */
export function exportToPdf(options: Omit<ExportHtmlOptions, 'filename'>): void {
  const fullHtml = generateStandaloneHtml(options);
  const printWindow = window.open('', '_blank');

  if (printWindow) {
    printWindow.document.open();
    printWindow.document.write(fullHtml);
    printWindow.document.close();

    // Trigger print dialog once loaded
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
      }, 400);
    };
  } else {
    // Fallback if popup blocker intercepted: use hidden iframe
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      doc.open();
      doc.write(fullHtml);
      doc.close();
      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 3000);
      }, 500);
    }
  }
}

/**
 * Helper to build the complete 1-month daily attendance book (28-31 pages)
 * ready for both Export HTML and Export PDF
 */
export function buildMonthAttendanceHtml(
  selectedYear: number,
  selectedMonth: number,
  allMonthData: Record<string, DayAttendanceMap>
): string {
  const daysInMonth = new Date(selectedYear, selectedMonth, 0).getDate();
  const monthName = KH_MONTHS_SOLAR[selectedMonth - 1];

  let pagesHtml = '';

  for (let d = 1; d <= daysInMonth; d++) {
    const mm = String(selectedMonth).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    const dateStr = `${selectedYear}-${mm}-${dd}`;
    const dayData = allMonthData[dateStr] || {};
    const dateObj = new Date(selectedYear, selectedMonth - 1, d);
    const dayName = KH_WEEKDAYS_LONG[dateObj.getDay()];
    const lunarDateStr = formatKhmerLunarDate(dateObj);
    const holiday = getKhmerHoliday(dateStr);
    const lunar = getKhmerLunarInfo(dateStr);

    const rowsHTML = STAFF_LIST.map((s, idx) => {
      const rec = dayData[s.name] || {};

      const sigCell = (recField?: any) => {
        if (recField && recField.sig) {
          return `<td style="text-align:center;border:1pt solid #000;padding:1pt 1.5pt;height:16pt;">
            <div style="display:flex;flex-direction:row;align-items:center;justify-content:center;gap:2pt;height:100%;">
              <img src="${recField.sig}" style="max-height:14pt;max-width:38pt;object-fit:contain;display:inline-block;" />
              <span style="font-size:6.5pt;font-weight:700;white-space:nowrap;line-height:1;">${recField.time || ''}</span>
            </div>
          </td>`;
        }
        return `<td style="border:1pt solid #000;padding:1pt;height:16pt;"></td>`;
      };

      const bg = idx % 2 === 1 ? 'background:#f8fafc;' : 'background:#ffffff;';

      return `<tr style="${bg};height:16pt;">
        <td style="text-align:center;border:1pt solid #000;padding:1pt;font-size:8pt;font-weight:700;">${toKhmer(idx + 1)}</td>
        <td style="border:1pt solid #000;padding:1pt 2pt;font-size:8.5pt;font-weight:700;white-space:nowrap;">${s.name}</td>
        <td style="text-align:center;border:1pt solid #000;padding:1pt;font-size:8pt;">${s.gender}</td>
        <td style="border:1pt solid #000;padding:1pt 2pt;font-size:8pt;white-space:nowrap;">${s.position}${s.cls !== '-' ? ' ' + s.cls : ''}</td>
        ${sigCell(rec.m_in)}
        ${sigCell(rec.m_out)}
        ${sigCell(rec.a_in)}
        ${sigCell(rec.a_out)}
        <td style="border:1pt solid #000;padding:1pt;text-align:center;font-size:7.5pt;">${rec.late || ''}</td>
        <td style="border:1pt solid #000;padding:1pt;text-align:center;font-size:7.5pt;">${rec.early || ''}</td>
        <td style="border:1pt solid #000;padding:1pt;text-align:center;font-size:7.5pt;">${rec.permissionDoc || ''}</td>
        <td style="border:1pt solid #000;padding:1pt;font-size:7.5pt;">${rec.note || ''}</td>
      </tr>`;
    }).join('');

    const directorSig = dayData['សុខ សារើន']?.m_in?.sig || dayData['សុខ សារើន']?.a_in?.sig;
    const isLast = d === daysInMonth;

    pagesHtml += `
      <div class="monthly-day-page ${!isLast ? 'page-break' : ''}" style="margin-bottom: ${isLast ? '0' : '20px'}; padding: 4mm 5mm; background: #fff; font-family: 'Kantumruy Pro', 'Noto Sans Khmer', sans-serif;">
        <div style="text-align:center;font-size:8pt;margin-bottom:2pt;">
          <p style="margin:0;font-family:'Moul',cursive;font-size:8.5pt;">ព្រះរាជាណាចក្រកម្ពុជា</p>
          <p style="margin:0;font-family:'Moul',cursive;font-size:8pt;">ជាតិ សាសនា ព្រះមហាក្សត្រ</p>
          <p style="margin:0;letter-spacing:2px;font-size:7.5pt;color:#555;">--------*--------</p>
        </div>

        <div style="text-align:left;font-size:7.5pt;line-height:1.2;margin-bottom:3pt;">
          <p style="margin:0;font-weight:700;">${SCHOOL_DISTRICT}</p>
          <p style="margin:0;font-weight:700;">${SCHOOL_OFFICE}</p>
          <p style="margin:0;font-weight:700;color:#1e3a8a;">${SCHOOL_NAME}</p>
        </div>

        <h3 style="text-align:center;font-family:'Moul',cursive;font-size:10.5pt;font-weight:normal;color:#1e3a8a;margin:1pt 0 0 0;">
          បញ្ជីវត្តមានប្រចាំថ្ងៃរបស់មន្ត្រីរាជការស៊ីវិល និងមន្ត្រីជាប់កិច្ចសន្យា
        </h3>
        <p style="text-align:center;font-size:8pt;font-weight:700;margin:0 0 1pt 0;">
          ${dayName} ទី${toKhmer(d)} ខែ${monthName} ឆ្នាំ${toKhmer(selectedYear)}
        </p>
        <p style="text-align:center;font-size:7pt;color:#475569;margin:0 0 2pt 0;">
          (${lunar.formattedLunar})
          ${holiday ? `<span style="color:#b91c1c;font-weight:bold;margin-left:4pt;">[ ថ្ងៃឈប់សម្រាកបុណ្យជាតិ: ${holiday.name} ]</span>` : ''}
        </p>

        <table style="width:100%;border-collapse:collapse;font-size:8.5pt;table-layout:fixed;">
          <thead>
            <tr style="background:#1d4ed8;color:#fff;">
              <th rowspan="2" style="border:1pt solid #000;padding:2pt;text-align:center;width:3.5%;">ល.រ</th>
              <th rowspan="2" style="border:1pt solid #000;padding:2pt;text-align:center;width:11%;">គោត្តនាមនិងនាម</th>
              <th rowspan="2" style="border:1pt solid #000;padding:2pt;text-align:center;width:3.5%;">ភេទ</th>
              <th rowspan="2" style="border:1pt solid #000;padding:2pt;text-align:center;width:8.5%;">តួនាទី</th>
              <th colspan="4" style="border:1pt solid #000;padding:2pt;text-align:center;width:42%;">ហត្ថលេខា</th>
              <th colspan="3" style="border:1pt solid #000;padding:2pt;text-align:center;width:20%;">ករណីផ្សេងៗ</th>
              <th rowspan="2" style="border:1pt solid #000;padding:2pt;text-align:center;width:11.5%;">ផ្សេងៗ</th>
            </tr>
            <tr style="background:#1e40af;color:#fff;font-size:7.5pt;">
              <th colspan="2" style="border:1pt solid #000;padding:1.5pt;text-align:center;width:26%;">ពេលព្រឹក</th>
              <th colspan="2" style="border:1pt solid #000;padding:1.5pt;text-align:center;width:16%;">ពេលរសៀល</th>
              <th style="border:1pt solid #000;padding:1.5pt;text-align:center;width:4.5%;">មកយឺត</th>
              <th style="border:1pt solid #000;padding:1.5pt;text-align:center;width:4.5%;">ចេញមុន</th>
              <th style="border:1pt solid #000;padding:1.5pt;text-align:center;width:11%;">លិខិតបញ្ជាក់</th>
            </tr>
            <tr style="background:#1e3a8a;color:#e2e8f0;font-size:7pt;">
              <th colspan="4" style="border:1pt solid #000;padding:1pt;text-align:center;"></th>
              <th style="border:1pt solid #000;padding:1pt;text-align:center;width:13%;">ចូល</th>
              <th style="border:1pt solid #000;padding:1pt;text-align:center;width:13%;">ចេញ</th>
              <th style="border:1pt solid #000;padding:1pt;text-align:center;width:8%;">ចូល</th>
              <th style="border:1pt solid #000;padding:1pt;text-align:center;width:8%;">ចេញ</th>
              <th colspan="4" style="border:1pt solid #000;padding:1pt;text-align:center;"></th>
            </tr>
          </thead>
          <tbody>${rowsHTML}</tbody>
        </table>

        <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:6pt;margin-top:3pt;padding-top:2pt;border-top:1pt solid #000;font-size:7.5pt;line-height:1.2;">
          <div style="background:#f8fafc;padding:3pt;border:0.5pt solid #cbd5e1;border-radius:3pt;">
            <p style="margin:0;font-weight:700;">សម្គាល់ ៖ ទណ្ឌកម្មវិន័យអនុវត្តចំពោះអវត្តមានគ្មានច្បាប់អនុញ្ញាត៖</p>
            <p style="margin:0;">១- មន្ត្រីរាជការស៊ីវិល៖ ស្តីបន្ទោស, ស្តីបន្ទោសដោយមានចំណារ, ផ្លាស់ដោយបង្ខំ, លុបឈ្មោះពីក្របខណ្ឌ</p>
            <p style="margin:0;">២- មន្ត្រីជាប់កិច្ចសន្យា៖ ណែនាំលើកទី១, ណែនាំចុងក្រោយ, លុបឈ្មោះពីអង្គភាពសាមី</p>
          </div>
          <div style="text-align:center;">
            <p style="margin:0;font-size:7pt;color:#555;">${lunarDateStr}</p>
            <p style="margin:0;font-weight:700;">រោគ ${dayName} ទី${toKhmer(d)} ខែ${monthName} ឆ្នាំ${toKhmer(selectedYear)}</p>
            <p style="margin:1pt 0;font-weight:700;font-size:8.5pt;color:#1e3a5f;">ប្រធាន / នាយិកា</p>
            <div style="height:26pt;display:flex;align-items:center;justify-content:center;">
              ${directorSig ? `<img src="${directorSig}" style="max-height:24pt;object-fit:contain;" />` : ''}
            </div>
            <p style="margin:0;font-weight:700;">សុខ សារើន</p>
          </div>
        </div>
      </div>
    `;
  }

  return pagesHtml;
}
